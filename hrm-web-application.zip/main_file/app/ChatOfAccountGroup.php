<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatOfAccountGroup extends Model
{
    //
}
